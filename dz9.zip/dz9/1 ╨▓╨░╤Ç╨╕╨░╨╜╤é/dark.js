function switchTheme() {
    let cont = document.querySelectorAll(".cont");
    let main = document.querySelectorAll("main");
    let wrapper = document.querySelectorAll(".wrapper");
    let footer = document.querySelectorAll("footer");

    for(item of cont){
    item.classList.toggle("darkTheme-cont");
    }
    for(item of main){
        item.classList.toggle("darkTheme-main");
    }
    for(item of wrapper){
        item.classList.toggle("darkTheme-wrapper");
    }
    for(item of footer){
        item.classList.toggle("darkTheme-footer");
    }

}








// function switchTheme() {
//     let switcher = document.getElementsByTagName("link")[0].href = "dark.css";
// }
